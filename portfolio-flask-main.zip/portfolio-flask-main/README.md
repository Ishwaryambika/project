# Satyam Mishra portfolio - Flask

This is my portfolio website made initally in django but later modified to work with flask.
Deployed to heorku

# folder app contains flask python file

# folder static contains three folders named favicon, universal-elements, website-files
        # which has static files required by home.html to run properly

# folder templates contains home.html file

# License is of type Creative Commons Legal Code

# requirements.txt contains modules required for this website to work

# runtime.txt specifys the python build version

# wsgi.py is runner file of app.py

![flask-in-python](https://user-images.githubusercontent.com/89126855/156156985-5c26ca9f-5901-4f63-a589-e21eff9613ad.svg)
